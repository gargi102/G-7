// Data for modal (can be replaced with dynamic data from a database)
const events = [
    {
      title: "Beach Wedding Bliss",
      description: "Celebrate love on a sunlit shore with the gentle sound of waves.",
      image: "event1.jpg"
    },
    {
      title: "Royal Palace Wedding",
      description: "Step into a fairytale with a majestic palace wedding.",
      image: "event2.jpg"
    },
    {
      title: "Garden Elegance",
      description: "Tie the knot amidst the enchanting beauty of nature.",
      image: "event3.jpg"
    }
  ];
  
  // Modal functionality
  function showModal(index) {
    const modal = document.getElementById('event-modal');
    const modalImage = document.getElementById('modal-image');
    const modalTitle = document.getElementById('modal-title');
    const modalDescription = document.getElementById('modal-description');
  
    modalImage.src = events[index - 1].image;
    modalTitle.textContent = events[index - 1].title;
    modalDescription.textContent = events[index - 1].description;
  
    modal.style.display = 'flex';
  }
  
  function closeModal() {
    const modal = document.getElementById('event-modal');
    modal.style.display = 'none';
  }
  document.getElementById('myButton').addEventListener('click', function() {
    // Open a new page (replace the URL with your desired page)
    window.location.href = 'register.html';  // Navigate to anotherPage.html
});