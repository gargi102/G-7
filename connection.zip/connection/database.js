
var mysql = require("mysql");

// Create a connection to the MySQL server
var con  = mysql.createConnection({
  host: 'localhost', // Change to your server's hostname
  user: 'root', // Replace with your MySQL username
  password: 'root_123', // Replace with your MySQL password
  database: 'tsm'
});

// Connect to the database
con.connect(function(err){
    if(err) throw err;
    con.query("select * from sign_up",function(error,result){
    if(error) throw error;
    console.log(result);
    });
});