/* document.addEventListener("DOMContentLoaded", () => {
  
    const sosForm = document.getElementById("sosForm");
    const reportsContainer = document.getElementById("reports");
  
    // Handle form submissior 
    sosForm.addEventListener("submit", (event) => {
      event.preventDefault();
  
      const username = document.getElementById("username").value;
      const password = document.getElementById("password").value;
      // const description = document.getElementById("description").value;
  
      if (animalType && location && description) {
        fetch('http://localhost:3000/addWedd', { // URL of your backend
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            username,
            password,
          }),
        })
        
          .then(response => response.json())
          .then(data => {
            if (data.message) {
              alert(data.message); // Success message
              document.getElementById("sosForm").reset();
            } else {
              alert('Error: ' + data.error);
            }
          })
          .catch(err => console.error('Error:', err));
      } else {
        alert('Please fill in all fields.');
      }
    });
  
    // Function to add a new report to the list
    function addReport(username, password) {
      const reportItem = document.createElement("div");
      reportItem.classList.add("report-item");
  
      reportItem.innerHTML = `
        <h3>${username}</h3>
        <p><strong>Location:</strong> ${password}</p>
      `;
  
      reportsContainer.appendChild(reportItem);
    }
    function goToPage(event) {
      event.preventDefault();
      window.location.href = "new.html";  // Navigate to another page
    }
 
  }); */
  document.addEventListener("DOMContentLoaded", () => {
    const sosForm = document.getElementById("sosForm");
    const cancelButton = document.querySelector(".cancelbtn");
  
    // Navigate to a new page when Cancel is clicked
    cancelButton.addEventListener("click", (event) => {
      event.preventDefault();
      window.location.href = "new.html";
    });
  
    // Handle form submission
    sosForm.addEventListener("submit", (event) => {
      event.preventDefault();
  
      const username = document.getElementById("username").value;
      const password = document.getElementById("password").value;
         
      if (username && password) {
        fetch("http://localhost:3000/addWedd", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            username,
            password,
          }),
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.message) {
              alert(data.message); // Success message
              sosForm.reset();
            } else {
              alert("Error: " + data.error);
            }
          })
          .catch((err) => console.error("Error:", err));
      } else {
        alert("Please fill in all fields.");
      }
    });
  });
  